/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author autologon
 */
public class ModelIMC {
    
    public ModelIMC(double peso, double altura) {
        this.peso = peso;
        this.altura = altura;
    }
    
    public void calculaIMC(double peso, double altura) {
        this.setImc(peso / (altura * altura));
    }
    
    public void classicacarIMC(double imc) {
        if (imc < 10.5) {
            this.setClassificacao("Estado de Desnutrição");
        } else if (imc < 25) {
            this.setClassificacao("peso normal");
        } else if (imc < 30) {
            this.setClassificacao("Sobrepeso");
        } else if (imc < 35) {
            this.setClassificacao("Obsidade I");
        } else if (imc < 40) {
            this.setClassificacao("Obsidade II");
        } else {
            this.setClassificacao("Obsidade III");
        }
    }
    
    private double peso, altura, imc;
    private String classificacao;
    
    public double getPeso() {
        return peso;
    }
    
    public void setPeso(double peso) {
        this.peso = peso;
    }
    
    public double getAltura() {
        return altura;
    }
    
    public void setAltura(double altura) {
        this.altura = altura;
    }
    
    public double getImc() {
        return imc;
    }
    
    public void setImc(double imc) {
        this.imc = imc;
    }
    
    public String getClassificacao() {
        return classificacao;
    }
    
    public void setClassificacao(String classificacao) {
        this.classificacao = classificacao;
    }
    
}
